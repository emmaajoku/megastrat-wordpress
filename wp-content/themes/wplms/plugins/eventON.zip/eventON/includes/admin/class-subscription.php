<?php
/** 
 * Subscription
 */

class EVO_Subscription{
	
}