<?php
/**
 * The template for displaying Miscellaneous course specific plugins
 *
 * Override this template by copying it to yourtheme/course/single/plugins.php
 *
 * @author 		VibeThemes
 * @package 	vibe-course-module/templates
 * @version     2.1
 */


?>